import java.io.*;
import java.util.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

@WebServlet("/SendToPojo")
public class SendToPojo extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
         throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  

//set values to variables get from user
String name=request.getParameter("ename");
int id=Integer.parseInt(request.getParameter("id"));
String date=request.getParameter("date");
int salary=Integer.parseInt(request.getParameter("salary"));
int phone=Integer.parseInt(request.getParameter("phone"));

//set values to pojo class

Pojo p=new Pojo();
{
p.setName(name);
p.setId(id);
p.setDate(date);
p.setSalary(salary);

int present=EmployeeDao.insert1(p);
if(present>0)
{
    out.println("inserted successfully");
}
else
{
    out.println("insertion unsuccess");
}

}
         }
}