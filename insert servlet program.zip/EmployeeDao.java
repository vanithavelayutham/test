import java.util.*;
import java.sql.*;

class EmployeeDao 
{
public static Connection getConnection()
{ 
    Connection c=null;
    try{
    Class.forName("com.mysql.jdbc.Driver");
    c=DriverManager.getConnection("jdbc:mysql://localhost:3306/registration1","root","");
}
catch(Exception e)
{
    System.out.println(e);}
    return c;
}
public static int insert1(Pojo p)
{
    int present=0;

   try {

Connection c=EmployeeDao.getConnection();
PreparedStatement ps=c.prepareStatement("insert into employee(name,id,date,salary,phone)values(?,?,?,?,?)");
ps.setString(1,p.getName());
ps.setInt(2,p.getId());
ps.setString(3,p.getDate());
ps.setInt(4,p.getSalary());
ps.setInt(5,p.getPhone());

present=ps.executeUpdate();
c.close();
}
catch(Exception e){
    System.out.println(e);

}
return present;
}
}